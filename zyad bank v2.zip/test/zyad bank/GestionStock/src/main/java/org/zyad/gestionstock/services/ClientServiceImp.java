package org.zyad.gestionstock.services;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Generated;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.zyad.gestionstock.entities.Client;
import org.zyad.gestionstock.repositories.ClientRepo;

import java.util.List;

@Service
@AllArgsConstructor
@Builder
public class ClientServiceImp implements ClientService{
    private ClientRepo clientRepo;



    @Override
    public Client saveClient(Client client) {
        return clientRepo.save(client);
    }

    @Override
    public Client updateClient(Client client) {
        return clientRepo.save(client);
    }

    @Override
    public void deleteClient(Long id) {
    clientRepo.deleteById(id);
    }

    @Override
    public void deleteAllClient() {
    clientRepo.deleteAll();
    }

    @Override
    public Client getClientById(Long id) {
        return clientRepo.findById(id).get();
    }

    @Override
    public List<Client> getAllClient() {
        return clientRepo.findAll();
    }

    @Override
    public Client findByMail(String mail) {
        return clientRepo.findClientByMail(mail);
    }

    @Override
    public Client login(String mail,String password) {
        return clientRepo.findClientByMailAndPassword(mail,password);
    }

    @Override
    public void updateSolde(Client client,float solde) {
        client.setSolde(client.getSolde()-solde);
    }


}
