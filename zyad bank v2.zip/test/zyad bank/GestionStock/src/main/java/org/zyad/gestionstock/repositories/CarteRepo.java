package org.zyad.gestionstock.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.zyad.gestionstock.entities.Carte;

@Repository
public interface CarteRepo extends JpaRepository<Carte,Long> {
    Carte getCarteByRel(Long rel);
}
