package org.zyad.gestionstock.controllers;

import ch.qos.logback.core.model.Model;
import com.github.javafaker.Faker;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.AllArgsConstructor;
import org.hibernate.annotations.Cache;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.zyad.gestionstock.entities.Carte;
import org.zyad.gestionstock.entities.Client;
import org.zyad.gestionstock.entities.Transaction;
import org.zyad.gestionstock.services.*;
import org.springframework.http.CacheControl;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Controller
@AllArgsConstructor
public class ClientController {
    private ClientService clientService;
    private CarteService carteService;
    private TransactionService transactionService;



    @ModelAttribute("savedClient")
    public Client setUpClient() {
        return new Client();
    }

    @RequestMapping("/creatClient")
    public String CreatClient(){

        return "creatClient";
    }
    @GetMapping("/")
    public String home() {
        return "home";
    }
    @PostMapping("/saveClient")
    public String saveClient(@ModelAttribute("clientvue") Client client){
        Carte carte = new Carte();
        Faker faker = new Faker();
        LocalDate localDate = LocalDate.now();
        carte.setCCV(faker.number().numberBetween(100,999));
        carte.setNumero(faker.number().numberBetween(0,999999999));
        carte.setDateouverture(localDate);
        client.setRIB(faker.number().numberBetween(0,999999999));
        client.setSolde(1000);
        Client saveClient = clientService.saveClient(client);
        carte.setRel(client.getId());
        Carte saveCarte = carteService.saveCarte(carte);
        return "Land";
    }
    @GetMapping("/connexion")
    public ModelAndView login(HttpServletRequest request) {
        ModelAndView mav = new ModelAndView("connexion");
        mav.addObject("client", new Client());
        request.getSession().setAttribute("savedClient", new Client());
        return mav;
    }

    @PostMapping("/connexion")
        public String connexion(@ModelAttribute("connexion") Client client,HttpServletRequest request){
        Client client1 = clientService.login(client.getMail(),client.getPassword());

        if(Objects.nonNull(client1)){
            request.getSession().setAttribute("savedClient", client1);
            return "index";
        }

        return "connexionech";
    }

    @GetMapping("/editclient")
    public ModelAndView editClient(HttpServletRequest request) {
        Client savedClient = (Client) request.getSession().getAttribute("savedClient");
        if(savedClient == null) {
            return new ModelAndView("redirect:/connexion");
        }
        ModelAndView mav = new ModelAndView("editclient");
        mav.addObject("client", savedClient);
        return mav;
    }
    @PostMapping("/editclient")
    public String saveEditedClient(@ModelAttribute("client") Client editedClient, HttpServletRequest request) {
        Client savedClient = (Client) request.getSession().getAttribute("savedClient");
        savedClient.setNom(editedClient.getNom());
        savedClient.setPrenom(editedClient.getPrenom());
        savedClient.setMail(editedClient.getMail());
        savedClient.setPassword(editedClient.getPassword());
        savedClient.setAdresse(editedClient.getAdresse());
        savedClient.setTel(editedClient.getTel());
        clientService.updateClient(savedClient);
        return "index";
    }

    @GetMapping("/deconnexion")
    public String deconnexion(){
        return "deconnexion";
    }

    @GetMapping("/solde")
    public String solde(HttpServletRequest request,ModelMap modelMap) {
        Client client1 = (Client) request.getSession().getAttribute("savedClient");
        modelMap.addAttribute("client",client1);
        return "solde";
    }
    @GetMapping("/info")
    public String info(HttpServletRequest request, ModelMap modelMap) {
        Client client1 = (Client) request.getSession().getAttribute("savedClient");
            Carte carte = carteService.findByRel(client1.getId());
            modelMap.addAttribute("client", client1);
            modelMap.addAttribute("carte", carte);
            return "info";
    }
    @GetMapping("/index")
    public String index(HttpServletRequest request, ModelMap modelMap) {
        Client client1 = (Client) request.getSession().getAttribute("savedClient");
        modelMap.addAttribute("client", client1);
        return "index";
    }



    @PostMapping("/virement")
    public String virement(@ModelAttribute("virement") Transaction transaction,HttpServletRequest request) {
        Transaction trans = (Transaction) request.getSession().getAttribute("savetrans");
        Client client1 = (Client) request.getSession().getAttribute("savedClient");
        LocalDate localDate = LocalDate.now();
        trans.setRel(client1.getId());
        trans.setDatetrans(localDate);
        trans.setDetails(transaction.getDetails());
        trans.setMontant(transaction.getMontant());
        trans.setDestination(transaction.getDestination());
        client1.setSolde(client1.getSolde()-transaction.getMontant());
        transactionService.saveTransaction(trans);
        clientService.updateClient(client1);
        return "index";
    }
    @GetMapping("/virement")
    public ModelAndView savetrans(HttpServletRequest request) {
        ModelAndView mav = new ModelAndView("virement");
        mav.addObject("transaction", new Transaction());
        request.getSession().setAttribute("savetrans", new Transaction());
        return mav;
    }

    @GetMapping("/transactionlist")
    public String transactionlist(HttpServletRequest request, ModelMap modelMap) {
        Client client1 = (Client) request.getSession().getAttribute("savedClient");
        List<Transaction> transaction = transactionService.findAllByRel(client1.getId());
        modelMap.addAttribute("client", client1);
        modelMap.addAttribute("transaction", transaction);
        return "transactionlist";
    }

}
