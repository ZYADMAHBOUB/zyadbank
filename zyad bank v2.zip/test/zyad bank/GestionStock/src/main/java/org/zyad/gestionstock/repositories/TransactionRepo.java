package org.zyad.gestionstock.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.zyad.gestionstock.entities.Carte;
import org.zyad.gestionstock.entities.Transaction;

import java.util.List;

@Repository
public interface TransactionRepo extends JpaRepository<Transaction,Long> {
    Transaction getTransactionByRel(Long rel);
    List<Transaction> getAllByRel(Long rel);
}
