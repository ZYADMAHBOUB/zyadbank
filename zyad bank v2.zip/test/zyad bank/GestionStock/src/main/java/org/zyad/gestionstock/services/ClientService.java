package org.zyad.gestionstock.services;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.zyad.gestionstock.entities.Carte;
import org.zyad.gestionstock.entities.Client;

import java.util.List;

@Service
public interface ClientService {

    Client saveClient(Client client);
    Client updateClient(Client client);
    void deleteClient(Long id);
    void deleteAllClient();
    Client getClientById(Long id);
    List<Client> getAllClient();
    Client findByMail(String mail);
    Client login(String mail,String password);
    void updateSolde(Client client,float solde);

}
