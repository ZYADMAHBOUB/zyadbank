package org.zyad.gestionstock.services;

import org.springframework.stereotype.Service;
import org.zyad.gestionstock.entities.Carte;

import java.util.List;

@Service
public interface CarteService {
    Carte saveCarte(Carte carte);
    Carte updateCarte(Carte carte);
    void deleteCarte(Long id);
    void deleteAllCarte();
    Carte getCarteById(Long id);
    List<Carte> getAllCarte();
    Carte findByRel(Long rel);
}
