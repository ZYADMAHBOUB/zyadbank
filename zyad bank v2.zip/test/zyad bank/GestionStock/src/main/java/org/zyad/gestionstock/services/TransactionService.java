package org.zyad.gestionstock.services;

import org.springframework.stereotype.Service;
import org.zyad.gestionstock.entities.Transaction;

import java.util.List;

@Service
public interface TransactionService {
    Transaction saveTransaction(Transaction transaction);
    Transaction updateTransaction(Transaction transaction);
    void deleteTransaction(Long id);
    void deleteAllTransaction();
    Transaction getTransactionById(Long id);
    List<Transaction> getAllTransaction();
    Transaction findTransByRel(Long rel);
    List<Transaction> findAllByRel(Long rel);
}
