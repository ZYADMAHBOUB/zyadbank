package org.zyad.gestionstock;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.zyad.gestionstock.entities.Client;
import org.zyad.gestionstock.repositories.ClientRepo;
import org.zyad.gestionstock.services.ClientServiceImp;

import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
public class GestionStockApplication {
    public static void main(String[] args) {
        SpringApplication.run(GestionStockApplication.class, args);
    }

}
