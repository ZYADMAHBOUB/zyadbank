package org.zyad.gestionstock.services;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.zyad.gestionstock.entities.Transaction;
import org.zyad.gestionstock.repositories.TransactionRepo;

import java.util.List;

@Service
@AllArgsConstructor
public class TransactionServiceImp implements TransactionService{
    private TransactionRepo transactionRepo;
    @Override
    public Transaction saveTransaction(Transaction transaction) {
        return transactionRepo.save(transaction);
    }

    @Override
    public Transaction updateTransaction(Transaction transaction) {
        return transactionRepo.save(transaction);
    }

    @Override
    public void deleteTransaction(Long id) {
    transactionRepo.deleteById(id);
    }

    @Override
    public void deleteAllTransaction() {
    transactionRepo.deleteAll();
    }

    @Override
    public Transaction getTransactionById(Long id) {
        return transactionRepo.findById(id).get();
    }

    @Override
    public List<Transaction> getAllTransaction() {
        return transactionRepo.findAll();
    }

    @Override
    public Transaction findTransByRel(Long rel) {
        return transactionRepo.getTransactionByRel(rel);
    }

    @Override
    public List<Transaction> findAllByRel(Long rel) {
        return transactionRepo.getAllByRel(rel);
    }
}
