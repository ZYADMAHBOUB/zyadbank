package org.zyad.gestionstock.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.zyad.gestionstock.entities.Client;

import java.util.List;

@Repository
public interface ClientRepo extends JpaRepository<Client,Long> {
     Client findClientByMail(String email);
     Client findClientByMailAndPassword(String mail,String password);

}
