package org.zyad.gestionstock.entities;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@DiscriminatorValue("VIREMENT")
@Data
@AllArgsConstructor
@NoArgsConstructor

public class Virement extends Transaction{
    private String details;
}
