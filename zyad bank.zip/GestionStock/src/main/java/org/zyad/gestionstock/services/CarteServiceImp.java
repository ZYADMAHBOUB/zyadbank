package org.zyad.gestionstock.services;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.zyad.gestionstock.entities.Carte;
import org.zyad.gestionstock.repositories.CarteRepo;

import java.util.List;

@Service
@AllArgsConstructor
public class CarteServiceImp implements CarteService{
    private CarteRepo carteRepo;
    @Override
    public Carte saveCarte(Carte carte) {
        return carteRepo.save(carte);
    }

    @Override
    public Carte updateCarte(Carte carte) {
        return carteRepo.save(carte);
    }

    @Override
    public void deleteCarte(Long id) {
        carteRepo.deleteById(id);
    }

    @Override
    public void deleteAllCarte() {
   carteRepo.deleteAll();
    }

    @Override
    public Carte getCarteById(Long id) {
        return carteRepo.findById(id).get();
    }

    @Override
    public List<Carte> getAllCarte() {
        return carteRepo.findAll();
    }

    @Override
    public Carte findByRel(Long rel) {
        return carteRepo.getCarteByRel(rel);
    }
}
