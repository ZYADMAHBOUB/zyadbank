package org.zyad.gestionstock.entities;

import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
public class Client {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nom;
    private String prenom;
    private String datenaissance;
    private String tel;
    private String mail;
    private String password;
    private String adresse;
    private float solde;
    private int RIB;
    @OneToOne(mappedBy = "client", fetch = FetchType.LAZY)
    private CompteEpargne compteEpargne;
    @OneToOne(mappedBy = "client", fetch = FetchType.LAZY)
    private CompteCourant compteCourant;
    @OneToMany(mappedBy = "client" , fetch = FetchType.LAZY)
    private List<Transaction> transactionList = new ArrayList<>();
    @OneToMany(mappedBy = "client" , fetch = FetchType.LAZY)
    private List<Carte> carteList = new ArrayList<>();

}
